import argparse
import os
from util.context import Context
import test_code as tc

# BQtoPostgreSQL/bqtopostgresql/script/postgresql.py


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Add required params')
    parser.add_argument(
        '--env',
        required=True,
        help='Add project or environment on which scripts are to be run example: bq'
    )

    args = parser.parse_args()
    jobRunID = os.getpid()
    print("**********",jobRunID )
    config_file = "/home/vsekar/BQtoPostgreSQL/bqtopostgresql/script/config.yaml"
    context = Context(config_file, args.env)
    tc.run(context)



#python3 file_name.py --env "bq"
#gcloud dataflow jobs run postgresql06 --gcs-location="gs://c360_apachebeam_01/02template_folder/bqpostgresql01"
# https://beam.apache.org/documentation/sdks/python-pipeline-dependencies/
# https://pythonhosted.org/an_example_pypi_project/setuptools.html
# https://googleapis.dev/python/logging/latest/stdlib-usage.html