#import libraries
import json
import os
import time
import argparse 
from util.context import Context, Settings

import logging
from google.cloud import logging

import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions
from apache_beam.options.pipeline_options import SetupOptions
from apache_beam.io.gcp.internal.clients import bigquery
from apache_beam.metrics import Metrics
from apache_beam.metrics.metric import MetricsFilter
from beam_nuggets.io import relational_db

def run(context):
    home = os.environ['HOME']
    pipeline_args = ['--project', context.settings.get('projectid'),
                     '--job_name', context.settings.get('jobname'),
                     '--runner', context.settings.get('runner'),
                     '--staging_location', context.settings.get('dataflow_staging'),
                     '--temp_location', context.settings.get('tempbucket'),
                     '--region', context.settings.get('region'),
                     '--template_location', context.settings.get('template_location'),
                     '--setup_file', context.settings.get('setup')]
                   
    #Configuring pipeline parameters
    pipeline_options = PipelineOptions(pipeline_args)

    # Instantiates a client
    logging_client = logging.Client()
    # The name of the log to write to
    log_name = context.settings.get('logname')
    # Selects the log to write to
    logger = logging_client.logger(log_name)
      
    
    #Reading it from config yaml file
    project_id = context.settings.get('projectid')
    dataset_id = context.settings.get('sourcetablename')
    table_id = context.settings.get('tableid')
    logger.log_text("The Project ID is {}".format(project_id))
    logger.log_text("The Dataset ID is {}".format(dataset_id))
    logger.log_text("The Table ID is {}".format(table_id))
    
    #Custom function for reading query
    def query_formation(project_id,dataset_id,table_id,where_condition= None):
        if where_condition == None:
            return 'SELECT * FROM '\
                            '[{}:{}.{}]'.format(project_id,dataset_id, table_id)
        else:
            return 'SELECT * FROM '\
                            '[{}:{}.{}] where {}'.format(project_id,dataset_id, table_id,where_condition)

    
    QUERY1 = 'SELECT * FROM '\
                    '[{}:{}.{}] '.format("dca-sandbox-project-4","00_bigquery_00", "AB_table")

    print("******", QUERY1)

    #Forming query
    input_query = query_formation(project_id,dataset_id,table_id)
    print("******", input_query)
    # count_query = count_query_formation(project_id,dataset_id,table_id)
    logger.log_text(input_query)
    logger.log_text("The input query is {}".format(input_query))
    

    #Target database instance
    source_config = relational_db.SourceConfiguration(
        drivername=context.settings.get('drivername'),
        host=context.settings.get('host'),
        port=context.settings.get('port'),
        database=context.settings.get('database'),
        username=context.settings.get('username'),
        password=context.settings.get('password'),
        create_if_missing=context.settings.get('create_if_missing')
    ) 
    
    logger.log_text("The Database is {}".format(context.settings.get('database')))

    #Target database table
    table_config = relational_db.TableConfiguration(
        name=context.settings.get('target_tableid'),
        create_if_missing=context.settings.get('create_if_missing')
    )

    table_config1 = relational_db.TableConfiguration(
        name=context.settings.get('target_tableid1'),
        create_if_missing=context.settings.get('create_if_missing')
    )

    logger.log_text("The Target table is {}".format(context.settings.get('target_tableid')))
    
    #Implementation Of Main Logic  
    try:
        #Creating a beam Pipeline
        p = beam.Pipeline(options=pipeline_options)
        #Creating a pcollection
        event = (
                p
                | 'Read from BQ' >>  beam.io.ReadFromBigQuery(query=input_query)
                )
        
        event_1 = (
                p
                | "Read from BQ1" >> beam.io.ReadFromBigQuery(query = QUERY1)
        )
                
        output1 = (
                event_1
                | 'Writing to DB1' >> relational_db.Write(
                        source_config=source_config,
                        table_config=table_config1))
        

        output = (
                event
                | 'Writing to DB' >> relational_db.Write(
                        source_config=source_config,
                        table_config=table_config))
        
        result = p.run()
        result.wait_until_finish()

    except Exception as e:
        print("The error is {}".format(e))
        logger.log_text(e)
        # context.logger.getLogger()
       
# https://www.programcreek.com/python/example/122923/apache_beam.CombineGlobally


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Add required params')
    parser.add_argument(
        '--env',
        required=True,
        help='Add project or environment on which scripts are to be run example: bq'
    )

    args = parser.parse_args()
    jobRunID = os.getpid()
    print("**********",jobRunID )
    config_file = "/home/vsekar/BQtoPostgreSQL/bqtopostgresql/script/config.yaml"
    context = Context(config_file, args.env)
    run(context)